const toggle = document.querySelector('.nav-toggle');
const nav = document.querySelector('.site-nav');

if (toggle && nav) {
  toggle.addEventListener('click', () => {
    const open = nav.classList.toggle('is-open');
    toggle.setAttribute('aria-expanded', String(open));
  });

  document.addEventListener('click', (event) => {
    if (!nav.classList.contains('is-open')) return;
    if (nav.contains(event.target) || toggle.contains(event.target)) return;
    nav.classList.remove('is-open');
    toggle.setAttribute('aria-expanded', 'false');
  });
}

function revealEmail(button) {
  const user = button.getAttribute('data-user');
  const domain = button.getAttribute('data-domain');
  if (!user || !domain) return;
  const address = `${user}@${domain}`;
  const wrapper = button.closest('.email-reveal');
  const target = wrapper ? wrapper.querySelector('.js-email-target') : null;
  if (!target) return;
  target.textContent = address;
  target.setAttribute('href', `mailto:${address}`);
  target.hidden = false;
  target.setAttribute('aria-hidden', 'false');
  button.hidden = true;
}

document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.js-email-reveal').forEach((button) => {
    button.addEventListener('click', () => revealEmail(button));
  });


  document.querySelectorAll('.js-email').forEach((link) => {
    const user = link.getAttribute('data-user');
    const domain = link.getAttribute('data-domain');
    if (!user || !domain) return;
    const address = `${user}@${domain}`;
    link.textContent = address;
    link.setAttribute('href', `mailto:${address}`);
  });

  const allFaqDetails = [...document.querySelectorAll('.faq-item')];
  allFaqDetails.forEach((detail) => {
    detail.addEventListener('toggle', () => {
      if (!detail.open) return;
      allFaqDetails.forEach((other) => {
        if (other !== detail) other.open = false;
      });
    });
  });
});
